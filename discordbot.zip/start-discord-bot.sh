#!/bin/bash
echo "Starting Discord Bot..."
echo "-----------------------"
echo "Make sure you have set your DISCORD_TOKEN in the .env file!"
echo "-----------------------"
node run-bot.js