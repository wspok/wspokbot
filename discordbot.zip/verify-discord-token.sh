#!/bin/bash
echo "Verifying Discord Token..."
echo "-------------------------"
echo "This will check if your Discord token is valid."
echo "-------------------------"
node verify-token.js