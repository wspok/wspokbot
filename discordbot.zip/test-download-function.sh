#!/bin/bash
echo "Testing Download Functionality..."
echo "--------------------------------"
echo "This will test the download capability using Cobalt.tools"
echo "It does not require a Discord token."
echo "--------------------------------"
node test-download.js